using System;

namespace $safeprojectname$
{
    public class User
    {
        public User() { }
        public virtual int Id { get; set; }
        public virtual string Username { get; set; }
        public virtual string Playfabid { get; set; }
        public virtual string Password { get; set; }
        public virtual DateTime? LastLoginTime { get; set; }

    }
}
